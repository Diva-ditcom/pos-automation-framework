# Empty file to make pos_automation a Python package
